@extends('layouts.maintenance')

@section('title', 'Gerenciamento de Categorias')

@section('content')
    <livewire:maintenance-category />
@endsection
