@extends('layouts.maintenance')

@section('title', 'Gerenciamento de Tarefas')

@section('content')
    <livewire:maintenance-task />
@endsection
