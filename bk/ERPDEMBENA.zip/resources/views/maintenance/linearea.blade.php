@extends('layouts.maintenance')

@section('title', 'Linhas & Áreas')

@section('content')
    <livewire:components.maintenance-line-area />
@endsection
