@extends('layouts.app')

@section('content')
    <livewire:maintenance-task />
@endsection
