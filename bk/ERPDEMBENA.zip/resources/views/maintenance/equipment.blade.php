@extends('layouts.maintenance')

@section('title', 'Gerenciamento de Equipamentos')

@section('content')
    <livewire:maintenance-equipment />
@endsection
