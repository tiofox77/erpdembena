@extends('layouts.app')

@section('content')
    <livewire:maintenance-equipment />
@endsection
