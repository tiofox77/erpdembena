<?php

namespace App\Livewire;

use App\Models\MaintenancePlan as MaintenancePlanModel;
use App\Models\MaintenanceEquipment;
use App\Models\MaintenanceArea;
use App\Models\MaintenanceLine;
use App\Models\MaintenanceTask;
use App\Models\User;
use Livewire\Component;
use Livewire\WithPagination;
use Carbon\Carbon;

class MaintenancePlan extends Component
{
    use WithPagination;

    public $showModal = false;
    public $isEditing = false;
    public $scheduleId;

    // Form fields
    public $task_id;
    public $equipment_id;
    public $line_id;
    public $area_id;
    public $scheduled_date;
    public $frequency_type = 'custom';
    public $custom_days;
    public $day_of_week;
    public $day_of_month;
    public $month;
    public $month_day;
    public $priority = 'medium';
    public $type = 'preventive';
    public $assigned_to;
    public $description;
    public $notes;
    public $status = 'in_progress';

    // Filters
    public $search = '';
    public $statusFilter = '';
    public $frequencyFilter = '';

    protected $rules = [
        'task_id' => 'required|exists:maintenance_tasks,id',
        'equipment_id' => 'required|exists:maintenance_equipment,id',
        'line_id' => 'nullable|exists:maintenance_lines,id',
        'area_id' => 'nullable|exists:maintenance_areas,id',
        'scheduled_date' => 'required|date',
        'frequency_type' => 'required|in:once,daily,custom,weekly,monthly,yearly',
        'custom_days' => 'required_if:frequency_type,custom|nullable|integer|min:1',
        'day_of_week' => 'required_if:frequency_type,weekly|nullable|integer|min:0|max:6',
        'day_of_month' => 'required_if:frequency_type,monthly|nullable|integer|min:1|max:31',
        'month' => 'required_if:frequency_type,yearly|nullable|integer|min:1|max:12',
        'month_day' => 'required_if:frequency_type,yearly|nullable|integer|min:1|max:31',
        'priority' => 'required|in:low,medium,high,critical',
        'type' => 'required|in:preventive,predictive,other',
        'assigned_to' => 'nullable|exists:users,id',
        'description' => 'nullable|string',
        'notes' => 'nullable|string',
        'status' => 'required|in:in_progress,completed,cancelled',
    ];

    protected $messages = [
        'task_id.required' => 'Please select a task.',
        'task_id.exists' => 'The selected task is invalid.',
        'equipment_id.required' => 'Please select equipment.',
        'equipment_id.exists' => 'The selected equipment is invalid.',
        'line_id.exists' => 'The selected line is invalid.',
        'area_id.exists' => 'The selected area is invalid.',
        'scheduled_date.required' => 'Please select a scheduled date.',
        'scheduled_date.date' => 'Please enter a valid date.',
        'frequency_type.required' => 'Please select a frequency type.',
        'frequency_type.in' => 'The selected frequency type is invalid.',
        'custom_days.required_if' => 'Please enter the number of days between occurrences.',
        'custom_days.integer' => 'Days must be a whole number.',
        'custom_days.min' => 'Days must be at least 1.',
        'day_of_week.required_if' => 'Please select a day of the week.',
        'day_of_week.integer' => 'Day of the week must be a whole number.',
        'day_of_week.min' => 'Day of the week must be between 0 and 6.',
        'day_of_week.max' => 'Day of the week must be between 0 and 6.',
        'day_of_month.required_if' => 'Please enter a day of the month.',
        'day_of_month.integer' => 'Day of the month must be a whole number.',
        'day_of_month.min' => 'Day of the month must be between 1 and 31.',
        'day_of_month.max' => 'Day of the month must be between 1 and 31.',
        'month.required_if' => 'Please select a month.',
        'month.integer' => 'Month must be a whole number.',
        'month.min' => 'Month must be between 1 and 12.',
        'month.max' => 'Month must be between 1 and 12.',
        'month_day.required_if' => 'Please enter a day of the month.',
        'month_day.integer' => 'Day of the month must be a whole number.',
        'month_day.min' => 'Day of the month must be between 1 and 31.',
        'month_day.max' => 'Day of the month must be between 1 and 31.',
        'priority.required' => 'Please select a priority.',
        'priority.in' => 'The selected priority is invalid.',
        'type.required' => 'Please select a type.',
        'type.in' => 'The selected type is invalid.',
        'assigned_to.exists' => 'The selected technician is invalid.',
        'status.required' => 'Please select a status.',
        'status.in' => 'The selected status is invalid.',
    ];

    protected $listeners = [
        'edit' => 'editSchedule',
        'delete' => 'delete',
        'calendarEventClick' => 'editSchedule',
        'createOnDate' => 'createOnDate',
        'openPlanModal' => 'openPlanModalWithDate'
    ];

    public function mount()
    {
        $this->resetForm();
        $this->updateCalendarEvents();
    }

    public function resetForm()
    {
        $this->reset([
            'task_id',
            'equipment_id',
            'line_id',
            'area_id',
            'scheduled_date',
            'frequency_type',
            'custom_days',
            'day_of_week',
            'day_of_month',
            'month',
            'month_day',
            'priority',
            'type',
            'assigned_to',
            'description',
            'notes',
            'status',
            'scheduleId',
            'isEditing'
        ]);
        $this->resetValidation();
    }

    public function openModal()
    {
        $this->resetForm();
        $this->showModal = true;
        $this->dispatch('showModalUpdated');
    }

    public function closeModal()
    {
        $this->resetForm();
        $this->showModal = false;
    }

    public function editSchedule($id)
    {
        $schedule = MaintenancePlanModel::findOrFail($id);
        $this->scheduleId = $schedule->id;
        $this->task_id = $schedule->task_id;
        $this->equipment_id = $schedule->equipment_id;
        $this->line_id = $schedule->line_id;
        $this->area_id = $schedule->area_id;
        $this->frequency_type = $schedule->frequency_type;
        $this->custom_days = $schedule->custom_days;
        $this->day_of_week = $schedule->day_of_week;
        $this->day_of_month = $schedule->day_of_month;
        $this->month = $schedule->month;
        $this->month_day = $schedule->month_day;
        $this->scheduled_date = $schedule->scheduled_date ? $schedule->scheduled_date->format('Y-m-d') : null;
        $this->priority = $schedule->priority;
        $this->type = $schedule->type;
        $this->assigned_to = $schedule->assigned_to;
        $this->description = $schedule->description;
        $this->notes = $schedule->notes;
        $this->status = $schedule->status;
        $this->isEditing = true;
        $this->showModal = true;
        $this->dispatch('showModalUpdated');
    }

    public function save()
    {
        try {
            // Validate the form fields
            $validatedData = $this->validate();

            // Handle new or update
            if ($this->isEditing) {
                $schedule = MaintenancePlanModel::findOrFail($this->scheduleId);
                $schedule->update($validatedData);
            } else {
                $schedule = MaintenancePlanModel::create($validatedData);
            }

            // Calculate next maintenance date
            $schedule->next_maintenance_date = $schedule->calculateNextMaintenanceDate();

            $schedule->save();

            // Enviar notificação usando formato simples e direto
            $msg = $this->isEditing ? 'O plano de manutenção foi atualizado com sucesso.' : 'Um novo plano de manutenção foi criado com sucesso.';
            $title = $this->isEditing ? 'Plano Atualizado' : 'Plano Criado';
            $type = $this->isEditing ? 'info' : 'success';

            // Teste direto com Javascript
            $this->js("toastr.$type('$msg', '$title')");

            $this->closeModal();
            $this->updateCalendarEvents();
        } catch (\Exception $e) {
            // Enviar notificação de erro usando formato direto com Javascript
            $msg = 'Ocorreu um erro ao salvar o plano: ' . $e->getMessage();
            $this->js("toastr.error('$msg', 'Erro')");
        }
    }

    public function delete($id)
    {
        try {
            $schedule = MaintenancePlanModel::findOrFail($id);
            $schedule->delete();

            // Enviar notificação usando JS direto
            $this->js("toastr.warning('O plano de manutenção foi excluído com sucesso.', 'Plano Excluído')");

            $this->updateCalendarEvents();
        } catch (\Exception $e) {
            // Enviar notificação de erro usando JS direto
            $msg = 'Ocorreu um erro ao excluir o plano. Por favor, tente novamente.';
            $this->js("toastr.error('$msg', 'Erro')");
        }
    }

    public function getFrequencyText($schedule)
    {
        return match ($schedule->frequency_type) {
            'once' => "Once",
            'daily' => "Daily",
            'custom' => "Every {$schedule->custom_days} days",
            'weekly' => "Weekly" . (isset($schedule->day_of_week) ? " (". Carbon::getDays()[$schedule->day_of_week] .")" : ""),
            'monthly' => "Monthly" . (isset($schedule->day_of_month) ? " (day {$schedule->day_of_month})" : ""),
            'yearly' => "Yearly" . (isset($schedule->month) && isset($schedule->month_day) ? " (" . Carbon::getMonthsOfYear()[$schedule->month] . " {$schedule->month_day})" : ""),
            default => "Unknown frequency"
        };
    }

    public function updateCalendarEvents()
    {
        // Generate calendar events from maintenance plans
        $events = MaintenancePlanModel::with(['equipment', 'task', 'line', 'area', 'assignedTo'])
            ->when($this->statusFilter, function ($query) {
                return $query->where('status', $this->statusFilter);
            })
            ->when($this->frequencyFilter, function ($query) {
                return $query->where('frequency_type', $this->frequencyFilter);
            })
            ->get()
            ->map(function ($schedule) {
                // Determine color based on status
                $color = match ($schedule->status) {
                    'pending' => '#10B981',     // green
                    'in_progress' => '#3B82F6', // blue
                    'completed' => '#059669',   // dark green
                    'cancelled' => '#6B7280',   // gray
                    default => '#10B981'        // default green
                };

                // Get title from task or use equipment name if task is not available
                $title = 'No Task';
                if ($schedule->task) {
                    $title = $schedule->task->title ?? $schedule->task->name ?? 'No Task';
                }

                // Format the event data for FullCalendar
                return [
                    'id' => $schedule->id,
                    'title' => $title,
                    'start' => $schedule->scheduled_date->format('Y-m-d'),
                    'end' => $schedule->scheduled_date->format('Y-m-d'),
                    'backgroundColor' => $color,
                    'borderColor' => $color,
                    'textColor' => '#FFFFFF',
                    'allDay' => true,
                    'extendedProps' => [
                        'equipment' => $schedule->equipment ? $schedule->equipment->name : 'No Equipment',
                        'serial_number' => $schedule->equipment ? $schedule->equipment->serial_number : 'N/A',
                        'task' => $title,
                        'line' => $schedule->line ? $schedule->line->name : 'N/A',
                        'area' => $schedule->area ? $schedule->area->name : 'N/A',
                        'assignedTo' => $schedule->assignedTo ? $schedule->assignedTo->name : 'Unassigned',
                        'frequency' => $this->getFrequencyText($schedule),
                        'lastMaintenance' => $schedule->last_maintenance_date ? $schedule->last_maintenance_date->format('M d, Y') : 'None',
                        'nextMaintenance' => $schedule->next_maintenance_date ? $schedule->next_maintenance_date->format('M d, Y') : 'N/A',
                        'status' => $schedule->status,
                        'priority' => $schedule->priority,
                        'type' => $schedule->type,
                        'description' => $schedule->description,
                    ]
                ];
            })
            ->toArray();

        // Add dummy events for testing if no events exist
        if (empty($events)) {
            $events = $this->getDummyEvents();
        }

        // Dispatch event with calendar event data
        $this->dispatch('calendarUpdated', $events);
    }

    /**
     * Generate dummy events for testing
     *
     * @return array
     */
    private function getDummyEvents()
    {
        $currentMonth = now()->format('Y-m');
        $dummyEvents = [];

        // Add some test events
        $dummyEvents[] = [
            'id' => 'test-1',
            'title' => 'teste',
            'start' => $currentMonth . '-20',
            'backgroundColor' => '#10B981',
            'borderColor' => '#10B981',
            'textColor' => '#FFFFFF',
            'allDay' => true,
            'extendedProps' => [
                'equipment' => 'Test Equipment',
                'serial_number' => 'TEST-123',
                'task' => 'teste',
                'frequency' => 'Once',
                'status' => 'pending',
                'priority' => 'medium',
                'type' => 'preventive',
                'description' => 'Test maintenance task'
            ]
        ];

        $dummyEvents[] = [
            'id' => 'test-2',
            'title' => 'teste',
            'start' => $currentMonth . '-22',
            'backgroundColor' => '#10B981',
            'borderColor' => '#10B981',
            'textColor' => '#FFFFFF',
            'allDay' => true,
            'extendedProps' => [
                'equipment' => 'Test Equipment',
                'serial_number' => 'TEST-123',
                'task' => 'teste',
                'frequency' => 'Once',
                'status' => 'pending',
                'priority' => 'medium',
                'type' => 'preventive',
                'description' => 'Test maintenance task'
            ]
        ];

        $dummyEvents[] = [
            'id' => 'test-3',
            'title' => 'teste',
            'start' => $currentMonth . '-27',
            'backgroundColor' => '#10B981',
            'borderColor' => '#10B981',
            'textColor' => '#FFFFFF',
            'allDay' => true,
            'extendedProps' => [
                'equipment' => 'Test Equipment',
                'serial_number' => 'TEST-123',
                'task' => 'teste',
                'frequency' => 'Once',
                'status' => 'pending',
                'priority' => 'medium',
                'type' => 'preventive',
                'description' => 'Test maintenance task'
            ]
        ];

        $dummyEvents[] = [
            'id' => 'test-4',
            'title' => 'teste',
            'start' => $currentMonth . '-29',
            'backgroundColor' => '#10B981',
            'borderColor' => '#10B981',
            'textColor' => '#FFFFFF',
            'allDay' => true,
            'extendedProps' => [
                'equipment' => 'Test Equipment',
                'serial_number' => 'TEST-123',
                'task' => 'teste',
                'frequency' => 'Once',
                'status' => 'pending',
                'priority' => 'medium',
                'type' => 'preventive',
                'description' => 'Test maintenance task'
            ]
        ];

        return $dummyEvents;
    }

    public function updatedSearch()
    {
        $this->resetPage();
        $this->updateCalendarEvents();
    }

    public function updatedStatusFilter()
    {
        $this->resetPage();
        $this->updateCalendarEvents();
    }

    public function updatedFrequencyFilter()
    {
        $this->resetPage();
        $this->updateCalendarEvents();
    }

    public function updatedFrequencyType()
    {
        // Resetar campos relacionados à frequência que não são relevantes
        // para o tipo de frequência selecionado
        switch ($this->frequency_type) {
            case 'once':
            case 'daily':
                $this->reset(['custom_days', 'day_of_week', 'day_of_month', 'month', 'month_day']);
                break;
            case 'custom':
                $this->reset(['day_of_week', 'day_of_month', 'month', 'month_day']);
                if (empty($this->custom_days)) {
                    // Definir um valor padrão para custom_days
                    $this->custom_days = 7; // Valor padrão de 7 dias
                }
                break;
            case 'weekly':
                $this->reset(['custom_days', 'day_of_month', 'month', 'month_day']);
                if (is_null($this->day_of_week)) {
                    // Definir o dia da semana padrão como o dia atual
                    $this->day_of_week = now()->dayOfWeek;
                }
                break;
            case 'monthly':
                $this->reset(['custom_days', 'day_of_week', 'month', 'month_day']);
                if (is_null($this->day_of_month)) {
                    // Definir o dia do mês padrão como o dia atual
                    $this->day_of_month = now()->day;
                }
                break;
            case 'yearly':
                $this->reset(['custom_days', 'day_of_week', 'day_of_month']);
                if (is_null($this->month) || is_null($this->month_day)) {
                    // Definir o mês e dia padrão como a data atual
                    $this->month = now()->month;
                    $this->month_day = now()->day;
                }
                break;
        }
    }

    /**
     * Edit maintenance plan schedule
     */
    public function edit($id)
    {
        $this->editSchedule($id);
    }

    /**
     * Open history notes modal for a maintenance plan
     */
    public function openHistory($id)
    {
        // Dispatch event to open the notes modal in view-only mode
        $this->dispatch('openHistoryModal', $id);
    }

    /**
     * Handle calendar date click to create a new maintenance plan on that date
     *
     * @param string $date
     * @return void
     */
    public function createOnDate($date)
    {
        $this->resetForm();
        $this->scheduled_date = $date;
        $this->showModal = true;
        $this->dispatch('showModalUpdated');
    }

    /**
     * Opens the maintenance plan modal with a pre-filled date
     */
    public function openPlanModalWithDate($date)
    {
        $this->resetForm();
        $this->scheduled_date = $date;
        $this->showModal = true;
        $this->dispatch('showModalUpdated');
    }

    public function render()
    {
        $schedules = MaintenancePlanModel::with(['equipment', 'line', 'area', 'task', 'assignedTo'])
            ->when($this->search, function ($query) {
                return $query->whereHas('equipment', function ($q) {
                    $q->where('name', 'like', '%' . $this->search . '%')
                      ->orWhere('serial_number', 'like', '%' . $this->search . '%');
                });
            })
            ->when($this->statusFilter, function ($query) {
                return $query->where('status', $this->statusFilter);
            })
            ->when($this->frequencyFilter, function ($query) {
                return $query->where('frequency_type', $this->frequencyFilter);
            })
            ->orderBy('scheduled_date')
            ->paginate(10);

        // Ensure calendar events are prepared
        $calendarEvents = [];
        try {
            // Get all events as an array for the calendar
            $calendarEvents = MaintenancePlanModel::with(['equipment', 'task', 'line', 'area', 'assignedTo'])
                ->when($this->statusFilter, function ($query) {
                    return $query->where('status', $this->statusFilter);
                })
                ->when($this->frequencyFilter, function ($query) {
                    return $query->where('frequency_type', $this->frequencyFilter);
                })
                ->get()
                ->map(function ($schedule) {
                    // Determine color based on status
                    $color = match ($schedule->status) {
                        'pending' => '#10B981',     // green
                        'in_progress' => '#3B82F6', // blue
                        'completed' => '#059669',   // dark green
                        'cancelled' => '#6B7280',   // gray
                        default => '#10B981'        // default green
                    };

                    // Get title from task or use equipment name if task is not available
                    $title = 'No Task';
                    if ($schedule->task) {
                        $title = $schedule->task->title ?? $schedule->task->name ?? 'No Task';
                    }

                    // Format the event data for FullCalendar
                    return [
                        'id' => $schedule->id,
                        'title' => $title,
                        'start' => $schedule->scheduled_date->format('Y-m-d'),
                        'end' => $schedule->scheduled_date->format('Y-m-d'),
                        'backgroundColor' => $color,
                        'borderColor' => $color,
                        'textColor' => '#FFFFFF',
                        'allDay' => true,
                        'extendedProps' => [
                            'equipment' => $schedule->equipment ? $schedule->equipment->name : 'No Equipment',
                            'serial_number' => $schedule->equipment ? $schedule->equipment->serial_number : 'N/A',
                            'task' => $title,
                            'line' => $schedule->line ? $schedule->line->name : 'N/A',
                            'area' => $schedule->area ? $schedule->area->name : 'N/A',
                            'assignedTo' => $schedule->assignedTo ? $schedule->assignedTo->name : 'Unassigned',
                            'frequency' => $this->getFrequencyText($schedule),
                            'lastMaintenance' => $schedule->last_maintenance_date ? $schedule->last_maintenance_date->format('M d, Y') : 'None',
                            'nextMaintenance' => $schedule->next_maintenance_date ? $schedule->next_maintenance_date->format('M d, Y') : 'N/A',
                            'status' => $schedule->status,
                            'priority' => $schedule->priority,
                            'type' => $schedule->type,
                            'description' => $schedule->description,
                        ]
                    ];
                })
                ->toArray();

            // Add dummy events for testing if no events exist
            if (empty($calendarEvents)) {
                $calendarEvents = $this->getDummyEvents();
            }
        } catch (\Exception $e) {
            // If there's an error, use the dummy events
            $calendarEvents = $this->getDummyEvents();
        }

        return view('livewire.maintenance-plan', [
            'schedules' => $schedules,
            'equipment' => MaintenanceEquipment::all(),
            'lines' => MaintenanceLine::all(),
            'areas' => MaintenanceArea::all(),
            'tasks' => MaintenanceTask::all(),
            'technicians' => User::where('role', 'technician')->get(),
            'frequencies' => [
                'once' => 'Once',
                'daily' => 'Daily',
                'custom' => 'Custom (days)',
                'weekly' => 'Weekly',
                'monthly' => 'Monthly',
                'yearly' => 'Yearly'
            ],
            'priorities' => [
                'low' => 'Low',
                'medium' => 'Medium',
                'high' => 'High',
                'critical' => 'Critical'
            ],
            'types' => [
                'preventive' => 'Preventive',
                'predictive' => 'Predictive',
                'other' => 'Other'
            ],
            'statuses' => [
                'in_progress' => 'In Progress',
                'completed' => 'Completed',
                'cancelled' => 'Cancelled'
            ],
            'calendarEvents' => $calendarEvents
        ]);
    }
}
