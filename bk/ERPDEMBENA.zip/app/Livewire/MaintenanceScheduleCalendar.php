<?php

namespace App\Livewire;

use Carbon\Carbon;
use Carbon\CarbonInterval;
use Carbon\CarbonPeriod;
use App\Models\MaintenancePlan;
use Livewire\Component;

class MaintenanceScheduleCalendar extends Component
{
    public $currentMonth;
    public $currentYear;
    public $calendarTitle;
    public $calendarDays = [];
    public $events = [];
    public $selectedDate;
    public $selectedDateEvents = [];

    // Array de cores para as tarefas
    private $taskColors = [
        'bg-blue-100 text-blue-800',
        'bg-green-100 text-green-800',
        'bg-yellow-100 text-yellow-800',
        'bg-red-100 text-red-800',
        'bg-purple-100 text-purple-800',
        'bg-pink-100 text-pink-800',
        'bg-indigo-100 text-indigo-800',
        'bg-cyan-100 text-cyan-800',
        'bg-teal-100 text-teal-800',
        'bg-orange-100 text-orange-800',
        'bg-amber-100 text-amber-800',
        'bg-lime-100 text-lime-800',
        'bg-emerald-100 text-emerald-800',
        'bg-sky-100 text-sky-800',
        'bg-fuchsia-100 text-fuchsia-800',
        'bg-rose-100 text-rose-800',
    ];

    // Cache de cores atribuídas por ID de tarefa
    private $assignedColors = [];

    protected $listeners = [
        'maintenanceUpdated' => 'loadEvents'
    ];

    // Função para converter data para o formato do calendário
    public function formatDate($date)
    {
        return Carbon::parse($date)->format('Y-m-d');
    }

    // Inicialização do componente
    public function mount()
    {
        $today = Carbon::today();
        $this->currentMonth = $today->month;
        $this->currentYear = $today->year;
        $this->selectedDate = $today->format('Y-m-d');

        $this->generateCalendar();
        $this->loadEvents();
    }

    // Gerar o calendário para o mês atual
    public function generateCalendar()
    {
        $this->calendarDays = [];

        // Definir o primeiro dia do mês
        $firstDayOfMonth = Carbon::createFromDate($this->currentYear, $this->currentMonth, 1);
        $lastDayOfMonth = $firstDayOfMonth->copy()->endOfMonth();

        // Definir o título do calendário em inglês (ex: "March 2025")
        // Configurar Carbon para usar inglês
        Carbon::setLocale('en');
        $this->calendarTitle = $firstDayOfMonth->format('F Y');

        // Obter dia da semana do primeiro dia (0 = Domingo, 6 = Sábado)
        $firstDayWeekday = $firstDayOfMonth->dayOfWeek;

        // Dias do mês anterior para preencher o início do calendário
        $prevMonth = $firstDayOfMonth->copy()->subMonth();
        $daysInPrevMonth = $prevMonth->daysInMonth;

        // Adicionar dias do mês anterior se necessário
        for ($i = $firstDayWeekday; $i > 0; $i--) {
            $day = $daysInPrevMonth - $i + 1;
            $date = Carbon::createFromDate($prevMonth->year, $prevMonth->month, $day);

            $this->calendarDays[] = [
                'date' => $date->format('Y-m-d'),
                'day' => $day,
                'isCurrentMonth' => false,
                'isToday' => $date->isToday(),
                'isWeekend' => $date->isWeekend(),
            ];
        }

        // Adicionar dias do mês atual
        for ($day = 1; $day <= $lastDayOfMonth->day; $day++) {
            $date = Carbon::createFromDate($this->currentYear, $this->currentMonth, $day);

            $this->calendarDays[] = [
                'date' => $date->format('Y-m-d'),
                'day' => $day,
                'isCurrentMonth' => true,
                'isToday' => $date->isToday(),
                'isWeekend' => $date->isWeekend(),
            ];
        }

        // Calcular quantos dias precisamos do próximo mês
        $daysFromNextMonth = 42 - count($this->calendarDays); // 42 = 6 semanas * 7 dias

        // Adicionar dias do próximo mês se necessário
        $nextMonth = $lastDayOfMonth->copy()->addMonth();
        for ($day = 1; $day <= $daysFromNextMonth; $day++) {
            $date = Carbon::createFromDate($nextMonth->year, $nextMonth->month, $day);

            $this->calendarDays[] = [
                'date' => $date->format('Y-m-d'),
                'day' => $day,
                'isCurrentMonth' => false,
                'isToday' => $date->isToday(),
                'isWeekend' => $date->isWeekend(),
            ];
        }
    }

    /**
     * Retorna uma cor para uma tarefa específica
     * @param int $taskId ID da tarefa
     * @param string $type Tipo da tarefa
     * @return string Classe CSS para cor
     */
    private function getEventColor($taskId, $type)
    {
        // Se já temos uma cor atribuída para esta tarefa, retornar ela
        if (isset($this->assignedColors[$taskId])) {
            return $this->assignedColors[$taskId];
        }

        // Escolher uma cor com base em um hash do ID da tarefa
        $index = $taskId % count($this->taskColors);

        // Tenta encontrar uma cor não usada recentemente
        $attempts = 0;
        $usedColors = array_values($this->assignedColors);

        while (in_array($this->taskColors[$index], $usedColors) && $attempts < 5) {
            $index = ($index + 1) % count($this->taskColors);
            $attempts++;
        }

        // Atribuir e armazenar a cor selecionada
        $this->assignedColors[$taskId] = $this->taskColors[$index];

        return $this->assignedColors[$taskId];
    }

    // Carregar eventos do mês atual
    public function loadEvents()
    {
        // Definir o primeiro e último dia do mês para buscar eventos
        $startDate = Carbon::createFromDate($this->currentYear, $this->currentMonth, 1)->startOfMonth();
        $endDate = $startDate->copy()->endOfMonth();

        // Buscar TODOS os eventos de manutenção ativos
        try {
            // Primeiro carregamos todos os planos de manutenção ativos
            $maintenancePlans = MaintenancePlan::with(['equipment', 'task'])
                ->where('status', '!=', 'cancelled')
                ->get();

            // Limpar eventos existentes
            $this->events = [];

            foreach ($maintenancePlans as $plan) {
                // Gerar ocorrências para este plano baseado na frequência
                $occurrences = $this->generateOccurrences($plan, $startDate, $endDate);

                // Processar cada ocorrência que cai neste mês
                foreach ($occurrences as $date) {
                    $formattedDate = $this->formatDate($date);

                    // Obter cor para esta tarefa
                    $colorClass = $this->getEventColor($plan->id, $plan->type);

                    $this->events[$formattedDate][] = [
                        'id' => $plan->id,
                        'title' => $plan->task ? $plan->task->title : 'Maintenance',
                        'equipment' => $plan->equipment ? $plan->equipment->name : 'Equipment',
                        'status' => $plan->status,
                        'type' => $plan->type,
                        'priority' => $plan->priority,
                        'description' => $plan->description,
                        'frequency' => $plan->frequency_type,
                        'color' => $colorClass,
                    ];
                }
            }

            // Carregar eventos para a data selecionada
            $this->updateSelectedDateEvents();

        } catch (\Exception $e) {
            // Em caso de erro, registramos mas não exibimos eventos
            // Log::error('Error loading events: ' . $e->getMessage());
        }
    }

    /**
     * Gera todas as ocorrências de um plano de manutenção dentro de um período
     * baseado no tipo de frequência configurado
     *
     * @param MaintenancePlan $plan O plano de manutenção
     * @param Carbon $startDate Data inicial do período
     * @param Carbon $endDate Data final do período
     * @return array Array de objetos Carbon com as datas de ocorrência
     */
    private function generateOccurrences($plan, $startDate, $endDate)
    {
        $occurrences = [];
        $scheduledDate = Carbon::parse($plan->scheduled_date);

        // Se a data agendada está fora do período e é posterior ao fim do período,
        // não teremos ocorrências deste plano neste mês
        if ($scheduledDate->greaterThan($endDate)) {
            return $occurrences;
        }

        // Para planos do tipo 'once' (única vez)
        if ($plan->frequency_type === 'once') {
            // Se cai dentro do período, adiciona
            if ($scheduledDate->greaterThanOrEqualTo($startDate) && $scheduledDate->lessThanOrEqualTo($endDate)) {
                $occurrences[] = $scheduledDate;
            }
            return $occurrences;
        }

        // Para planos recorrentes
        $currentDate = $scheduledDate->copy();

        // Se a data agendada é anterior ao início do período, precisamos avançar
        // até a primeira ocorrência dentro do período
        while ($currentDate->lessThan($startDate)) {
            $currentDate = $this->getNextOccurrence($currentDate, $plan);
        }

        // Agora adicionamos todas as ocorrências dentro do período
        while ($currentDate->lessThanOrEqualTo($endDate)) {
            $occurrences[] = $currentDate->copy();
            $currentDate = $this->getNextOccurrence($currentDate, $plan);
        }

        return $occurrences;
    }

    /**
     * Calcula a próxima ocorrência baseada na frequência
     *
     * @param Carbon $currentDate Data atual
     * @param MaintenancePlan $plan Plano de manutenção
     * @return Carbon A próxima data de ocorrência
     */
    private function getNextOccurrence($currentDate, $plan)
    {
        $nextDate = $currentDate->copy();

        switch ($plan->frequency_type) {
            case 'daily':
                return $nextDate->addDay();

            case 'custom':
                // Avança o número de dias personalizado
                return $nextDate->addDays($plan->custom_days ?? 1);

            case 'weekly':
                // Se tem dia da semana definido, avança para o próximo dia específico
                if (!is_null($plan->day_of_week)) {
                    // Primeiro avançamos uma semana
                    $nextDate = $nextDate->addWeek();
                    // Depois ajustamos para o dia da semana desejado
                    return $nextDate->startOfWeek()->addDays($plan->day_of_week);
                }
                // Se não tem dia específico, simplesmente avança 7 dias
                return $nextDate->addWeek();

            case 'monthly':
                $nextDate = $nextDate->addMonth();
                // Se tem dia do mês definido, ajusta para esse dia
                if (!is_null($plan->day_of_month)) {
                    $daysInMonth = $nextDate->daysInMonth;
                    $day = min($plan->day_of_month, $daysInMonth);
                    return $nextDate->setDay($day);
                }
                return $nextDate;

            case 'yearly':
                $nextDate = $nextDate->addYear();
                // Se tem mês e dia definidos, ajusta para essa data
                if (!is_null($plan->month) && !is_null($plan->month_day)) {
                    // Verificação para 29 de fevereiro em anos não bissextos
                    if ($plan->month == 2 && $plan->month_day == 29 && !$nextDate->isLeapYear()) {
                        return $nextDate->setMonth(2)->setDay(28);
                    }
                    return $nextDate->setMonth($plan->month)->setDay($plan->month_day);
                }
                return $nextDate;

            default:
                return $nextDate->addDay(); // Fallback para diário
        }
    }

    // Atualizar eventos da data selecionada
    public function updateSelectedDateEvents()
    {
        $this->selectedDateEvents = $this->events[$this->selectedDate] ?? [];
    }

    // Navegar para o mês anterior
    public function previousMonth()
    {
        $date = Carbon::createFromDate($this->currentYear, $this->currentMonth, 1)->subMonth();
        $this->currentMonth = $date->month;
        $this->currentYear = $date->year;

        $this->generateCalendar();
        $this->loadEvents();
    }

    // Navegar para o próximo mês
    public function nextMonth()
    {
        $date = Carbon::createFromDate($this->currentYear, $this->currentMonth, 1)->addMonth();
        $this->currentMonth = $date->month;
        $this->currentYear = $date->year;

        $this->generateCalendar();
        $this->loadEvents();
    }

    // Selecionar uma data específica
    public function selectDate($date)
    {
        $this->selectedDate = $date;
        $this->updateSelectedDateEvents();
    }

    // Resetar para o mês atual
    public function resetToday()
    {
        $today = Carbon::today();
        $this->currentMonth = $today->month;
        $this->currentYear = $today->year;
        $this->selectedDate = $today->format('Y-m-d');

        $this->generateCalendar();
        $this->loadEvents();
    }

    // Editar um evento
    public function editEvent($eventId)
    {
        // Disparar evento para abrir o modal de notas
        $this->dispatch('openNotesModal', $eventId);
    }

    // Renderizar o componente
    public function render()
    {
        return view('livewire.maintenance-schedule-calendar');
    }
}
