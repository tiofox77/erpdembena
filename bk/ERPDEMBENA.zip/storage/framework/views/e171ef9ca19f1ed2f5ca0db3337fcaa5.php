<div>
<!--[if BLOCK]><![endif]--><?php if($showModal): ?>
<div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity z-50 flex items-center justify-center overflow-y-auto">
    <div class="bg-white rounded-lg overflow-hidden shadow-xl transform transition-all w-full max-w-4xl">
        <!-- Modal Header -->
        <div class="bg-gray-50 px-6 py-4 border-b border-gray-200 flex justify-between items-center">
            <h3 class="text-lg font-medium text-gray-900">
                <!--[if BLOCK]><![endif]--><?php if($viewOnly): ?>
                    Maintenance History: <?php echo e($task['title']); ?> - <?php echo e($task['equipment']); ?>

                <?php else: ?>
                    Maintenance Notes: <?php echo e($task['title']); ?> - <?php echo e($task['equipment']); ?>

                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </h3>
            <button wire:click="closeModal" class="text-gray-400 hover:text-gray-500">
                <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>

        <!-- Modal Body -->
        <div class="px-6 py-4">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Column 1: Task Details -->
                <div class="col-span-1">
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <h4 class="font-medium text-gray-700 mb-3">Task Details</h4>

                        <div class="mb-2">
                            <span class="text-sm font-medium text-gray-500">ID:</span>
                            <span class="text-sm text-gray-900 ml-1"><?php echo e($task['id']); ?></span>
                        </div>

                        <div class="mb-2">
                            <span class="text-sm font-medium text-gray-500">Task:</span>
                            <span class="text-sm text-gray-900 ml-1"><?php echo e($task['title']); ?></span>
                        </div>

                        <div class="mb-2">
                            <span class="text-sm font-medium text-gray-500">Equipment:</span>
                            <span class="text-sm text-gray-900 ml-1"><?php echo e($task['equipment']); ?></span>
                        </div>

                        <div class="mb-4">
                            <span class="text-sm font-medium text-gray-500">Status:</span>
                            <span class="px-2 py-0.5 text-xs rounded-full ml-1
                                <?php echo e($task['status'] === 'in_progress' ? 'bg-blue-100 text-blue-800' : ''); ?>

                                <?php echo e($task['status'] === 'completed' ? 'bg-green-100 text-green-800' : ''); ?>

                                <?php echo e($task['status'] === 'cancelled' ? 'bg-gray-100 text-gray-800' : ''); ?>">
                                <?php echo e(ucfirst($task['status'])); ?>

                            </span>
                        </div>

                        <!--[if BLOCK]><![endif]--><?php if(!$viewOnly): ?>
                        <h5 class="font-medium text-gray-700 text-sm mb-2">Update Status:</h5>
                        <div class="flex space-x-2">
                            <button wire:click="updateStatus('in_progress')" class="px-2 py-1 text-xs rounded bg-blue-100 text-blue-800 hover:bg-blue-200">
                                In Progress
                            </button>
                            <button wire:click="updateStatus('completed')" class="px-2 py-1 text-xs rounded bg-green-100 text-green-800 hover:bg-green-200">
                                Completed
                            </button>
                            <button wire:click="updateStatus('cancelled')" class="px-2 py-1 text-xs rounded bg-gray-100 text-gray-800 hover:bg-gray-200">
                                Cancelled
                            </button>
                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <!-- Column 2: Note Form and History -->
                <div class="col-span-2">
                    <!--[if BLOCK]><![endif]--><?php if(!$viewOnly): ?>
                    <h4 class="font-medium text-gray-700 mb-3">Add New Note</h4>

                    <form wire:submit.prevent="saveNote" class="mb-4">
                        <div class="mb-3">
                            <label for="notes" class="block text-sm font-medium text-gray-700 mb-1">Activity Description</label>
                            <textarea
                                id="notes"
                                wire:model="notes"
                                rows="4"
                                class="w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                placeholder="Describe what was done during maintenance..."
                            ></textarea>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="flex justify-end">
                            <button type="submit" class="px-4 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md shadow-sm hover:bg-blue-700">
                                Add Note
                            </button>
                        </div>
                    </form>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!-- Notes History -->
                    <div>
                        <h4 class="font-medium text-gray-700 mb-3 <?php echo e(!$viewOnly ? 'border-t pt-3' : ''); ?>">Activity History</h4>

                        <!--[if BLOCK]><![endif]--><?php if(empty($history)): ?>
                            <p class="text-sm text-gray-500 italic">No activity records found</p>
                        <?php else: ?>
                            <div class="space-y-3">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="p-3 border rounded-md bg-gray-50">
                                        <div class="flex justify-between mb-1">
                                            <span class="text-xs font-medium text-gray-500">
                                                <?php echo e($note['created_at']); ?> by <?php echo e($note['user']); ?>

                                            </span>
                                            <span class="px-2 py-0.5 text-xs rounded-full
                                                <?php echo e($note['status'] === 'in_progress' ? 'bg-blue-100 text-blue-800' : ''); ?>

                                                <?php echo e($note['status'] === 'completed' ? 'bg-green-100 text-green-800' : ''); ?>

                                                <?php echo e($note['status'] === 'cancelled' ? 'bg-gray-100 text-gray-800' : ''); ?>">
                                                <?php echo e(ucfirst($note['status'])); ?>

                                            </span>
                                        </div>
                                        <p class="text-sm text-gray-900 whitespace-pre-line"><?php echo e($note['notes']); ?></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Footer -->
        <div class="bg-gray-50 px-6 py-3 flex justify-end">
            <button
                wire:click="closeModal"
                class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50"
            >
                Close
            </button>
        </div>
    </div>
</div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\laragon\www\ERPDEMBENA\resources\views/livewire/maintenance-note-modal.blade.php ENDPATH**/ ?>