@extends('layouts.livewire')

@section('title', 'Plano de Manutenção')

@section('content')
    <livewire:maintenance-plan />
@endsection
