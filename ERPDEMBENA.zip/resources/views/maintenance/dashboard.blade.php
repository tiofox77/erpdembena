@extends('layouts.maintenance')

@section('title', 'Dashboard')

@section('content')
    <livewire:maintenance-dashboard />
@endsection
