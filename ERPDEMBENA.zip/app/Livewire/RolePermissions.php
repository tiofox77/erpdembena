<?php

namespace App\Livewire;

use Livewire\Component;

class RolePermissions extends Component
{
    public function render()
    {
        return view('livewire.role-permissions');
    }
}
