<?php

namespace App\Livewire\Reports;

use Livewire\Component;

class MaintenanceHistory extends Component
{
    public function render()
    {
        return view('livewire.reports.maintenance-history');
    }
}
