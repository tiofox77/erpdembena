<?php

namespace App\Livewire\Reports;

use Livewire\Component;

class ReportsDashboard extends Component
{
    public function render()
    {
        return view('livewire.reports.reports-dashboard');
    }
}
